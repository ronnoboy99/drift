package com.drift.app.ui.theme

import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.drift.app.R

// Dark purple palette (from the fintech reference): near-black ground, lavender accent.
val Bg = Color(0xFF14141A)
val Panel = Color(0xFF1F1F28)       // search field, cards, segmented track
val PanelHi = Color(0xFF2E2A4A)     // selected chip, fullscreen button
val IconBtn = Color(0xFF24242E)     // round header buttons
val Line = Color(0xFF2A2A35)
val Accent = Color(0xFFB7A6FF)
val AccentEnd = Color(0xFF8FA8FF)
val OnAccent = Color(0xFF1A1530)
val TextPrimary = Color(0xFFF4F2FF)
val TextMuted = Color(0xFFA09CB8)
val AccentBrush = Brush.linearGradient(listOf(Accent, AccentEnd))

/** Inter from Google Fonts (SIL Open Font License, see licenses/Inter-OFL.txt): one variable font, one file per weight slot. */
private val Inter = FontFamily(
    Font(R.font.inter, FontWeight.Normal),
    Font(R.font.inter, FontWeight.Medium),
    Font(R.font.inter, FontWeight.SemiBold),
    Font(R.font.inter, FontWeight.Bold),
)

private fun typographyFor(family: FontFamily): Typography {
    val t = Typography()
    fun TextStyle.f() = copy(fontFamily = family)
    return Typography(
        displayLarge = t.displayLarge.f(), displayMedium = t.displayMedium.f(), displaySmall = t.displaySmall.f(),
        headlineLarge = t.headlineLarge.f(), headlineMedium = t.headlineMedium.f(), headlineSmall = t.headlineSmall.f(),
        titleLarge = t.titleLarge.f(), titleMedium = t.titleMedium.f(), titleSmall = t.titleSmall.f(),
        bodyLarge = t.bodyLarge.f(), bodyMedium = t.bodyMedium.f(), bodySmall = t.bodySmall.f(),
        labelLarge = t.labelLarge.f(), labelMedium = t.labelMedium.f(), labelSmall = t.labelSmall.f(),
    )
}

private val Scheme = darkColorScheme(
    primary = Accent,
    onPrimary = OnAccent,
    background = Bg,
    onBackground = TextPrimary,
    surface = Bg,
    onSurface = TextPrimary,
    surfaceVariant = Panel,
    onSurfaceVariant = TextMuted,
    outline = Line,
)

@Composable
fun DriftTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = typographyFor(Inter)) {
        // Plain Text() calls take their font from here, not from the Material typography.
        CompositionLocalProvider(
            LocalTextStyle provides LocalTextStyle.current.merge(TextStyle(fontFamily = Inter)),
            content = content,
        )
    }
}
