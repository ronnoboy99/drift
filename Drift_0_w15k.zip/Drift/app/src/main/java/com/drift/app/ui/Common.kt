package com.drift.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drift.app.InstagramViewModel
import com.drift.app.ui.theme.Accent
import com.drift.app.ui.theme.Bg
import com.drift.app.ui.theme.IconBtn
import com.drift.app.ui.theme.PanelHi
import com.drift.app.ui.theme.TextMuted
import com.drift.app.ui.theme.TextPrimary

@Composable
fun RoundIconButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(IconBtn).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, description, tint = TextPrimary, modifier = Modifier.size(22.dp)) }
}

@Composable
fun SearchField(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    onAction: () -> Unit = {},
) {
    Box(modifier.heightIn(min = 46.dp), contentAlignment = Alignment.CenterStart) {
        if (value.isEmpty()) Text(placeholder, color = TextMuted, fontSize = 15.sp, maxLines = 1)
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = LocalTextStyle.current.copy(color = TextPrimary, fontSize = 15.sp),
            cursorBrush = SolidColor(Accent),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onDone = { onAction() }, onGo = { onAction() }),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

/** A round profile picture (when Instagram's data had one) or the first letter of the name. */
@Composable
fun Avatar(vm: InstagramViewModel, name: String, size: Dp, tint: Color = PanelHi) {
    val url = remember(vm.version, name) { vm.avatarUrl(name) }
    val bmp by produceState<Bitmap?>(null, url) { value = url?.let { vm.loadBitmap(it, 128) } }
    Box(Modifier.size(size).clip(CircleShape).background(tint), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) {
            Image(remember(b) { b.asImageBitmap() }, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text(name.take(1).uppercase(), color = Accent, fontSize = (size.value * 0.42f).sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** A small round icon for menu rows. */
@Composable
fun MenuIcon(icon: ImageVector) {
    Box(Modifier.size(28.dp).clip(CircleShape).background(PanelHi), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = Accent, modifier = Modifier.size(16.dp))
    }
}

/** One row of a drop-up or the hold menu: leading picture, label, optional small trailing text, a check when selected. */
@Composable
fun MenuRow(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    trailing: String? = null,
    leading: @Composable () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(14.dp))
            .background(if (selected) PanelHi else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        leading()
        Text(
            label, color = TextPrimary, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        if (trailing != null) Text(trailing, color = TextMuted, fontSize = 13.sp)
        if (selected) Icon(AppIcons.Check, null, tint = Accent, modifier = Modifier.size(18.dp))
    }
}

@Composable
fun SectionTag(text: String) {
    Text(
        text, color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp,
        modifier = Modifier.padding(start = 10.dp, top = 10.dp, bottom = 4.dp),
    )
}

@Composable
fun HintText(text: String, modifier: Modifier = Modifier) {
    Text(text, color = TextMuted, fontSize = 13.sp, modifier = modifier.padding(10.dp))
}

val CardBg get() = Bg
