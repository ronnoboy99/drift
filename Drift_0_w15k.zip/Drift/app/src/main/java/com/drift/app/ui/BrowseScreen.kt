package com.drift.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.drift.app.InstagramViewModel
import com.drift.app.Tab
import com.drift.app.data.Feed
import com.drift.app.data.IgMedia
import com.drift.app.data.parseInstagramProfile
import com.drift.app.ui.theme.Accent
import com.drift.app.ui.theme.Bg
import com.drift.app.ui.theme.Panel
import com.drift.app.ui.theme.TextMuted
import com.drift.app.ui.theme.TextPrimary
import kotlinx.coroutines.delay

/**
 * The main screen, always fullscreen. It is Drift's own feed (Home or Saved tab), with a floating navbar.
 * Settings opens over it; the in-app Browser (real instagram.com) opens from Settings or "Open in browser".
 * The Browser's WebView stays composed underneath the whole time, so it keeps loading what the feed shows.
 */
@Composable
fun BrowseScreen(vm: InstagramViewModel, settingsOpen: Boolean, onSettings: () -> Unit) {
    val s = vm.state
    val cfg = vm.settings
    val web = vm.browser
    val tab = vm.tabNow()
    val feed = vm.visibleFeed()
    var query by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    var menuTab by remember { mutableStateOf(Tab.HOME) }
    var hold by remember { mutableStateOf<IgMedia?>(null) }       // the post whose hold menu is open
    var sending by remember { mutableStateOf<IgMedia?>(null) }    // the post whose Send sheet is open
    var area by remember { mutableStateOf(IntSize.Zero) }
    val focus = LocalFocusManager.current
    val view = LocalView.current
    val activity = view.context.findActivity()
    val immersive = !settingsOpen     // fullscreen everywhere except Settings, which needs the normal insets

    LaunchedEffect(Unit) { vm.drive() }
    LaunchedEffect(settingsOpen, s.browser) {
        if (settingsOpen || s.browser) { menuOpen = false; hold = null; sending = null }
    }
    LaunchedEffect(s.notice) {
        if (s.notice != null) { delay(2200); vm.clearNotice() }
    }
    DisposableEffect(web) {      // a new WebView (after Android killed the old one) gets resumed too
        web.onResume()
        onDispose { runCatching { web.onPause() } }
    }

    // Always fullscreen: the status and navigation bars are hidden (a swipe from the edge shows them briefly).
    DisposableEffect(immersive) {
        val controller = activity?.window?.let { WindowCompat.getInsetsController(it, view) }
        if (immersive) {
            controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller?.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }

    fun goBack() {
        when {
            hold != null -> hold = null
            sending != null -> sending = null
            menuOpen -> menuOpen = false
            s.browser -> if (web.canGoBack()) web.goBack() else vm.closeBrowser()
            s.profileView != null -> vm.closeProfileView()
            else -> activity?.finish()
        }
    }
    BackHandler(enabled = !settingsOpen) { goBack() }

    fun go() {
        focus.clearFocus()
        vm.browserGo(query)
    }

    if (s.askUsername) UsernameDialog(onDismiss = vm::dismissUsernamePrompt, onSave = vm::saveMe)

    Box(Modifier.fillMaxSize().background(Bg).onSizeChanged { area = it }) {
        Column(Modifier.fillMaxSize().imePadding()) {
            if (s.browser) {
                // Browser only: close it, and a slim bar to type a profile name or link.
                Row(
                    Modifier.displayCutoutPadding().padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    RoundIconButton(AppIcons.Back, "Close browser", vm::closeBrowser)
                    Row(
                        Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(Panel),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        SearchField(
                            query, { query = it }, "Profile name or link",
                            Modifier.weight(1f).padding(start = 16.dp),
                            onAction = ::go,
                        )
                        Text(
                            "Go", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable(onClick = ::go).padding(horizontal = 16.dp, vertical = 14.dp),
                        )
                    }
                }
                s.error?.let {
                    Text(
                        it, color = MaterialTheme.colorScheme.error, fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                    )
                }
            }

            // The browser stays composed under the feed so it keeps its page and scroll position.
            val top = if (s.browser) 20.dp else 0.dp
            Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(topStart = top, topEnd = top))) {
                androidx.compose.runtime.key(web) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = {
                            (web.parent as? ViewGroup)?.removeView(web)
                            web
                        },
                    )
                }
                if (!s.browser) {
                    androidx.compose.runtime.key(feed.encode()) {
                        FeedList(vm, feed, onHold = { hold = it }, onOpenBrowser = { vm.openBrowser() })
                    }
                    s.profileView?.let { pv ->
                        androidx.compose.runtime.key(pv.user) { ProfileScreen(vm, pv, onHold = { hold = it }) }
                    }
                }
            }
        }

        if (!s.browser) {
            // Hold Home / Hold Saved: the page dims and a drop-up opens beside the navbar.
            val (menuAlign, menuPad) = menuPlacement(cfg.dock)
            val fromTop = isTopDock(cfg.dock)
            AnimatedVisibility(visible = menuOpen, enter = fadeIn(), exit = fadeOut()) { Scrim { menuOpen = false } }
            AnimatedVisibility(
                visible = menuOpen,
                modifier = Modifier.align(menuAlign).padding(menuPad),
                enter = fadeIn() + expandVertically(expandFrom = if (fromTop) Alignment.Top else Alignment.Bottom),
                exit = fadeOut() + shrinkVertically(shrinkTowards = if (fromTop) Alignment.Top else Alignment.Bottom),
            ) {
                if (menuTab == Tab.HOME) {
                    HomeMenu(vm, s.homeFeed, s.profiles) { menuOpen = false; vm.pickHome(it) }
                } else {
                    SavedMenu(vm, s.savedFeed, s.groups) { menuOpen = false; vm.pickSaved(it) }
                }
            }

            NavBar(
                dock = cfg.dock,
                area = area,
                onDock = { cfg.setDock(it) },
                showHome = cfg.showHome.value,
                showSaved = cfg.showSaved.value,
                homeActive = tab == Tab.HOME && s.profileView == null && !menuOpen,
                savedActive = tab == Tab.SAVED && s.profileView == null && !menuOpen,
                onHome = { menuOpen = false; vm.selectTab(Tab.HOME) },
                onSaved = { menuOpen = false; vm.selectTab(Tab.SAVED) },
                onHoldHome = { menuTab = Tab.HOME; menuOpen = true },
                onHoldSaved = { menuTab = Tab.SAVED; menuOpen = true; vm.refreshGroups() },
                onSettings = onSettings,
            )

            hold?.let { m ->
                HoldMenu(vm, m, onDismiss = { hold = null }, onSend = { sending = m })
            }
            sending?.let { m -> SendSheet(vm, m, onDismiss = { sending = null }) }
        }

        // A short message: "Saved", "Sent to 2"...
        AnimatedVisibility(
            visible = s.notice != null,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 56.dp),
            enter = fadeIn(), exit = fadeOut(),
        ) {
            Text(
                s.notice.orEmpty(), color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(Panel).padding(horizontal = 16.dp, vertical = 10.dp),
            )
        }
    }
}

/** Shown when Saved can't find out who is signed in: type your username once and it is remembered. */
@Composable
private fun UsernameDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    val valid = parseInstagramProfile(name) != null
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Your Instagram username", color = TextPrimary, fontWeight = FontWeight.SemiBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "I couldn't find it on the page. It's needed for the link to your saved posts, and I'll remember it.",
                    color = TextMuted, fontSize = 14.sp,
                )
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Bg).padding(horizontal = 16.dp)) {
                    SearchField(name, { name = it }, "username", onAction = { parseInstagramProfile(name)?.let(onSave) })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { parseInstagramProfile(name)?.let(onSave) }, enabled = valid) {
                Text("Open saved", color = if (valid) Accent else TextMuted)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = TextMuted) } },
    )
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
