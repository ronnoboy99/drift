package com.drift.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drift.app.InstagramViewModel
import com.drift.app.data.Feed
import com.drift.app.data.IgMedia
import com.drift.app.data.SavedGroup
import com.drift.app.ui.theme.Accent
import com.drift.app.ui.theme.AccentBrush
import com.drift.app.ui.theme.IconBtn
import com.drift.app.ui.theme.Line
import com.drift.app.ui.theme.OnAccent
import com.drift.app.ui.theme.Panel
import com.drift.app.ui.theme.PanelHi
import com.drift.app.ui.theme.TextMuted
import com.drift.app.ui.theme.TextPrimary

private val CardShape = RoundedCornerShape(22.dp)
val ScrimColor = Color(0x990A0A0E)

@Composable
fun Scrim(onDismiss: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(ScrimColor).clickable(
            interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss,
        ),
    )
}

/** Hold Home: Home, All profiles, or one saved profile. */
@Composable
fun HomeMenu(vm: InstagramViewModel, current: Feed, profiles: List<String>, onPick: (Feed) -> Unit) {
    LazyColumn(
        Modifier.width(284.dp).heightIn(max = 420.dp).clip(CardShape).background(Panel).border(1.dp, Line, CardShape).padding(8.dp),
    ) {
        item {
            MenuRow("Home", current.kind == Feed.Kind.HOME, { onPick(Feed.Home) }) { MenuIcon(AppIcons.Home) }
        }
        item {
            MenuRow(
                "All profiles", current.kind == Feed.Kind.ALL_PROFILES, { onPick(Feed.AllProfiles) },
                trailing = profiles.size.toString(),
            ) { MenuIcon(AppIcons.Layers) }
        }
        item { SectionTag("PROFILES") }
        if (profiles.isEmpty()) {
            item { HintText("None saved yet. Hold a post, go to its profile and tap the save button, or add several in Settings.") }
        } else {
            items(profiles, key = { it }) { name ->
                MenuRow(
                    "@$name", current.kind == Feed.Kind.PROFILE && current.key.equals(name, ignoreCase = true),
                    { onPick(Feed.profile(name)) },
                ) { Avatar(vm, name, 28.dp) }
            }
        }
    }
}

/** Hold Saved: All posts, or one group. */
@Composable
fun SavedMenu(vm: InstagramViewModel, current: Feed, groups: List<SavedGroup>, onPick: (Feed) -> Unit) {
    LazyColumn(
        Modifier.width(284.dp).heightIn(max = 420.dp).clip(CardShape).background(Panel).border(1.dp, Line, CardShape).padding(8.dp),
    ) {
        item {
            MenuRow("All posts", current.kind == Feed.Kind.SAVED_ALL, { onPick(Feed.SavedAll) }) { MenuIcon(AppIcons.Saved) }
        }
        item { SectionTag("GROUPS") }
        if (groups.isEmpty()) {
            item { HintText("No groups yet. They load from your Instagram Saved page; make sure you're signed in (Settings → Browser).") }
        } else {
            items(groups, key = { it.id }) { g ->
                MenuRow(g.name, current.kind == Feed.Kind.SAVED_GROUP && current.key == g.id, { onPick(Feed.group(g.id)) }) {
                    Box(Modifier.size(28.dp).clip(CircleShape).background(PanelHi), contentAlignment = Alignment.Center) {
                        Text(g.name.take(1).uppercase(), color = Accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

/** Hold a post: Save post, Go to profile, Send to chat (only with Chat on), Save to device, Open in browser. */
@Composable
fun HoldMenu(
    vm: InstagramViewModel,
    m: IgMedia,
    onDismiss: () -> Unit,
    onSend: () -> Unit,
) {
    val saved = remember(m.post, vm.version) { vm.isSaved(m.post) }
    Box(Modifier.fillMaxSize()) {
        Scrim(onDismiss)
        Column(
            Modifier.align(Alignment.Center).width(284.dp).clip(CardShape).background(Panel).border(1.dp, Line, CardShape).padding(8.dp),
        ) {
            HoldRow(AppIcons.Saved, if (saved) "Unsave post" else "Save post") { onDismiss(); vm.toggleSave(m) }
            if (m.owner.isNotEmpty()) HoldRow(AppIcons.User, "Go to @${m.owner}") { onDismiss(); vm.openProfileView(m.owner) }
            if (vm.settings.chat.value) HoldRow(AppIcons.Send, "Send to chat") { onDismiss(); onSend() }
            HoldRow(AppIcons.Download, "Save to device") { onDismiss(); vm.saveToDevice(m) }
            HoldRow(AppIcons.External, "Open in browser") { onDismiss(); vm.openInBrowser(m) }
        }
    }
}

@Composable
private fun HoldRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    MenuRow(label, false, onClick) { MenuIcon(icon) }
}

/** Send to chat: pick one or more conversations, then send the post's link. Only reachable when Chat is on. */
@Composable
fun SendSheet(vm: InstagramViewModel, m: IgMedia, onDismiss: () -> Unit) {
    val picked = remember { mutableStateOf(setOf<String>()) }
    LaunchedEffect(Unit) { vm.loadChats() }
    val chats = vm.chats
    Box(Modifier.fillMaxSize()) {
        Scrim(onDismiss)
        val shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().heightIn(max = 520.dp)
                .clip(shape).background(Panel).border(1.dp, Line, shape)
                .navigationBarsPadding().padding(start = 12.dp, end = 12.dp, top = 16.dp, bottom = 12.dp),
        ) {
            Text("Send to", color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 8.dp, bottom = 8.dp))
            Box(Modifier.weight(1f, fill = false)) {
                when {
                    chats == null -> Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = TextMuted, modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                    }
                    vm.chatsFailed -> HintText("Couldn't load your chats. Make sure you're signed in (Settings → Browser), then try again.")
                    chats.isEmpty() -> HintText("No conversations found.")
                    else -> LazyColumn {
                        items(chats, key = { it.id }) { t ->
                            val on = t.id in picked.value
                            MenuRow(
                                t.title, on,
                                { picked.value = if (on) picked.value - t.id else picked.value + t.id },
                            ) {
                                Box(Modifier.size(32.dp).clip(CircleShape).background(PanelHi), contentAlignment = Alignment.Center) {
                                    Text(t.title.take(1).uppercase(), color = Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
            val n = picked.value.size
            Box(
                Modifier.padding(top = 10.dp).fillMaxWidth().height(50.dp).clip(RoundedCornerShape(16.dp))
                    .background(if (n > 0) AccentBrush else androidx.compose.ui.graphics.SolidColor(IconBtn))
                    .clickable(enabled = n > 0) { vm.sendToChats(m, picked.value.toList()); onDismiss() },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (n > 0) "Send to $n" else "Pick who to send to",
                    color = if (n > 0) OnAccent else TextMuted, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}
