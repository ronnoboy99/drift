package com.drift.app.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

/** Line icons as vector paths (tinted at the call site). */
object AppIcons {
    private fun icon(name: String, vararg paths: String, filled: Boolean = false): ImageVector =
        ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).apply {
            paths.forEach { d ->
                addPath(
                    pathData = PathParser().parsePathString(d).toNodes(),
                    fill = if (filled) SolidColor(Color.White) else null,
                    stroke = SolidColor(Color.White),
                    strokeLineWidth = 1.8f,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                )
            }
        }.build()

    val Back by lazy { icon("back", "M15 5l-7 7 7 7") }
    val Settings by lazy {
        icon(
            "settings", "M4 7h10", "M18 7h2", "M4 17h2", "M10 17h10",
            "M14 7a2 2 0 1 0 4 0a2 2 0 1 0 -4 0", "M6 17a2 2 0 1 0 4 0a2 2 0 1 0 -4 0",
        )
    }
    val Home by lazy { icon("home", "M4 11l8-7 8 7v9h-5v-6H9v6H4z") }
    val Saved by lazy { icon("saved", "M7 4h10v16l-5-4-5 4z") }
    val Profiles by lazy {
        icon(
            "profiles", "M9 11a3 3 0 1 0 0-6a3 3 0 0 0 0 6z", "M3 19c0-3 3-5 6-5s6 2 6 5",
            "M16 6a3 3 0 0 1 0 5", "M18 14c2 .6 3 2.2 3 5",
        )
    }
    val More by lazy {
        icon(
            "more", "M12 4a1 1 0 1 0 0 2a1 1 0 1 0 0-2z", "M12 11a1 1 0 1 0 0 2a1 1 0 1 0 0-2z",
            "M12 18a1 1 0 1 0 0 2a1 1 0 1 0 0-2z", filled = true,
        )
    }
    val Go by lazy { icon("go", "M5 12h14", "M13 6l6 6-6 6") }
    val Close by lazy { icon("close", "M7 7l10 10", "M17 7L7 17") }
    val User by lazy { icon("user", "M12 12a4 4 0 1 0 0-8a4 4 0 0 0 0 8z", "M4 20c0-4 4-6 8-6s8 2 8 6") }
    val UserAdd by lazy {
        icon(
            "user_add", "M9 11a3 3 0 1 0 0-6a3 3 0 0 0 0 6z", "M3 19c0-3 3-5 6-5s4 1 5 2",
            "M18 8v6", "M15 11h6",
        )
    }
    val Send by lazy { icon("send", "M21 3L3 10l7 3 3 7z", "M21 3L10 13") }
    val Download by lazy { icon("download", "M12 4v11", "M7 11l5 5 5-5", "M5 20h14") }
    val External by lazy { icon("external", "M14 4h6v6", "M20 4l-9 9", "M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5") }
    val Globe by lazy {
        icon("globe", "M12 21a9 9 0 1 0 0-18a9 9 0 0 0 0 18z", "M3 12h18", "M12 3c3 3 3 15 0 18", "M12 3c-3 3-3 15 0 18")
    }
    val Check by lazy { icon("check", "M5 12l5 5 9-10") }
    val Layers by lazy { icon("layers", "M12 4l9 5-9 5-9-5z", "M3 14l9 5 9-5") }
}
