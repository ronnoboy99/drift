package com.drift.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** A Saved group (an Instagram collection). */
data class SavedGroup(val id: String, val name: String)

/** What the Home or Saved feed shows. Stored as a short string so it survives restarts. */
data class Feed(val kind: Kind, val key: String? = null) {
    enum class Kind { HOME, ALL_PROFILES, PROFILE, SAVED_ALL, SAVED_GROUP }

    fun encode() = if (key == null) kind.name else "${kind.name}:$key"

    companion object {
        val Home = Feed(Kind.HOME)
        val AllProfiles = Feed(Kind.ALL_PROFILES)
        val SavedAll = Feed(Kind.SAVED_ALL)
        fun profile(name: String) = Feed(Kind.PROFILE, name)
        fun group(id: String) = Feed(Kind.SAVED_GROUP, id)

        fun decode(s: String?, fallback: Feed): Feed {
            if (s == null) return fallback
            val kind = runCatching { Kind.valueOf(s.substringBefore(':')) }.getOrNull() ?: return fallback
            val key = if (s.contains(':')) s.substringAfter(':') else null
            return Feed(kind, key)
        }
    }
}

/** Remembers the saved profiles, Saved groups, your username and what Home and Saved were last set to. */
class InstagramStore(context: Context) {
    private val prefs = context.getSharedPreferences("instagram", Context.MODE_PRIVATE)

    /** The signed-in account's own username, once known (the saved-posts page lives under it). */
    var me: String?
        get() = prefs.getString("me", null)
        set(v) { prefs.edit().putString("me", v).apply() }

    /** Saved profiles, most recently added first. */
    var profiles: List<String>
        get() = runCatching {
            val a = JSONArray(prefs.getString("profiles", "[]"))
            List(a.length()) { a.getString(it) }
        }.getOrDefault(emptyList())
        set(v) { prefs.edit().putString("profiles", JSONArray(v).toString()).apply() }

    var groups: List<SavedGroup>
        get() = runCatching {
            val a = JSONArray(prefs.getString("groups", "[]"))
            List(a.length()) { val o = a.getJSONObject(it); SavedGroup(o.getString("id"), o.getString("name")) }
        }.getOrDefault(emptyList())
        set(v) {
            val a = JSONArray()
            v.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name)) }
            prefs.edit().putString("groups", a.toString()).apply()
        }

    var homeFeed: Feed
        get() = Feed.decode(prefs.getString("home_feed", null), Feed.Home)
        set(v) { prefs.edit().putString("home_feed", v.encode()).apply() }

    var savedFeed: Feed
        get() = Feed.decode(prefs.getString("saved_feed", null), Feed.SavedAll)
        set(v) { prefs.edit().putString("saved_feed", v.encode()).apply() }
}
