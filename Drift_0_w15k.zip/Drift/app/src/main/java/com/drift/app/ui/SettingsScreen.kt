package com.drift.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign.Companion.Center
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drift.app.data.DriftSettings
import com.drift.app.data.Flag
import com.drift.app.ui.theme.Accent
import com.drift.app.ui.theme.AccentBrush
import com.drift.app.ui.theme.Bg
import com.drift.app.ui.theme.IconBtn
import com.drift.app.ui.theme.OnAccent
import com.drift.app.ui.theme.Panel
import com.drift.app.ui.theme.TextMuted
import com.drift.app.ui.theme.TextPrimary

/** Everything on one screen: navbar buttons, feed types, ads and chat, bulk-add profiles, Browser, reset and sign out. */
@Composable
fun SettingsScreen(
    cfg: DriftSettings,
    saved: List<String>,
    parseProfiles: (String) -> List<String>,
    onAddProfiles: (String) -> Unit,
    onBrowser: () -> Unit,
    onResetFeed: () -> Unit,
    onSignOut: () -> Unit,
    onBack: () -> Unit,
) {
    BackHandler(onBack = onBack)
    var confirmSignOut by remember { mutableStateOf(false) }
    if (confirmSignOut) {
        AlertDialog(
            onDismissRequest = { confirmSignOut = false },
            containerColor = Panel,
            title = { Text("Sign out?", color = TextPrimary, fontWeight = FontWeight.SemiBold) },
            text = {
                Text(
                    "This wipes the in-app browser (login, cookies, history) and every loaded feed, then starts over at Instagram. Your saved profiles stay.",
                    color = TextMuted, fontSize = 14.sp,
                )
            },
            confirmButton = {
                TextButton(onClick = { confirmSignOut = false; onSignOut(); onBack() }) {
                    Text("Sign out", color = Color(0xFFFF7A8A))
                }
            },
            dismissButton = { TextButton(onClick = { confirmSignOut = false }) { Text("Cancel", color = TextMuted) } },
        )
    }
    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()),   // only needed on very small screens
    ) {
        Row(
            Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(IconBtn).clickable(onClick = onBack),
                contentAlignment = Alignment.Center,
            ) { Icon(AppIcons.Back, "Back", tint = TextPrimary, modifier = Modifier.size(22.dp)) }
            Text(
                "Settings", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                textAlign = Center, modifier = Modifier.weight(1f).padding(end = 54.dp),
            )
        }

        SectionLabel("NAVBAR")
        TileRow {
            ToggleTile("Home", cfg.showHome)
            ToggleTile("Saved", cfg.showSaved)
        }

        SectionLabel("SHOW IN FEED")
        TileRow {
            ToggleTile("Photos", cfg.photos)
            ToggleTile("Reels", cfg.reels)
        }

        SectionLabel("MORE")
        TileRow {
            ToggleTile("Hide ads", cfg.hideAds)
            ToggleTile("Chat", cfg.chat)
        }
        if (cfg.chat.value) {
            Text(
                "Adds Send to chat to the hold menu. Drift reads your chat list and sends the post's link through Instagram's own page, only when you use it.",
                color = TextMuted, fontSize = 12.sp,
                modifier = Modifier.padding(start = 32.dp, end = 32.dp, bottom = 16.dp),
            )
        }

        SectionLabel("ADD SAVED PROFILES")
        BulkAdd(saved, parseProfiles, onAddProfiles)

        Row(
            Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ActionTile("Browser", TextPrimary) { onBrowser() }
            ActionTile("Reset feed", TextPrimary) { onResetFeed(); onBack() }
            ActionTile("Sign out", Color(0xFFFF7A8A)) { confirmSignOut = true }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text, color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp,
        modifier = Modifier.padding(start = 32.dp, end = 32.dp, bottom = 8.dp),
    )
}

@Composable
private fun Segmented(labels: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Panel).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        labels.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).heightIn(min = 44.dp).clip(RoundedCornerShape(11.dp))
                    .then(if (on) Modifier.background(AccentBrush) else Modifier)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                Text(label, color = if (on) OnAccent else TextMuted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun TileRow(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp).fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        content = content,
    )
}

/** A small on/off tile: the label on the left, the switch on the right. The whole tile is the toggle target. */
@Composable
private fun RowScope.ToggleTile(title: String, flag: Flag) {
    Row(
        Modifier.weight(1f).heightIn(min = 52.dp).clip(RoundedCornerShape(16.dp)).background(Panel)
            .toggleable(value = flag.value, role = Role.Switch, onValueChange = flag::set)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.weight(1f))
        DriftSwitch(flag.value)
    }
}

@Composable
private fun RowScope.ActionTile(title: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.weight(1f).heightIn(min = 52.dp).clip(RoundedCornerShape(16.dp)).background(Panel).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(title, color = color, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
}

/** Paste profile names or links (commas, spaces or new lines between them) and add them all at once. */
@Composable
private fun BulkAdd(saved: List<String>, parseProfiles: (String) -> List<String>, onAdd: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    val found = remember(text) { parseProfiles(text) }
    val fresh = found.filter { n -> saved.none { it.equals(n, ignoreCase = true) } }
    val label = if (found.isEmpty()) "Paste names or links" else "${fresh.size} new · ${found.size - fresh.size} already saved"
    Column(
        Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp).fillMaxWidth()
            .clip(RoundedCornerShape(20.dp)).background(Panel).padding(12.dp),
    ) {
        Box(Modifier.fillMaxWidth().height(72.dp).clip(RoundedCornerShape(14.dp)).background(Bg).padding(horizontal = 14.dp, vertical = 12.dp)) {
            if (text.isEmpty()) {
                Text("Separated by commas, spaces or new lines", color = TextMuted, fontSize = 14.sp)
            }
            BasicTextField(
                value = text,
                onValueChange = { text = it },
                textStyle = LocalTextStyle.current.copy(color = TextPrimary, fontSize = 15.sp),
                cursorBrush = SolidColor(Accent),
                modifier = Modifier.fillMaxSize(),
            )
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(label, color = TextMuted, fontSize = 13.sp, modifier = Modifier.weight(1f))
            val enabled = fresh.isNotEmpty()
            Box(
                Modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(14.dp))
                    .background(if (enabled) AccentBrush else SolidColor(IconBtn))
                    .clickable(enabled = enabled) { onAdd(text); text = "" }
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (enabled) "Add ${fresh.size}" else "Add",
                    color = if (enabled) OnAccent else TextMuted, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

/** Visual only: the whole tile is the toggle target. */
@Composable
private fun DriftSwitch(checked: Boolean) {
    val x by animateDpAsState(if (checked) 16.dp else 0.dp, label = "switch")
    Box(
        Modifier.size(width = 40.dp, height = 24.dp).clip(CircleShape)
            .background(if (checked) Accent else Color(0xFF34343F)).padding(3.dp),
    ) {
        Box(Modifier.offset(x = x).size(18.dp).clip(CircleShape).background(Color.White))
    }
}
