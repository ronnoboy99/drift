package com.drift.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.drift.app.InstagramViewModel
import com.drift.app.ui.theme.Bg

/** Two screens: the feed (with the hidden/in-app browser behind it) and Settings, which slides in over it. */
@Composable
fun AppRoot(ig: InstagramViewModel = viewModel()) {
    var showSettings by rememberSaveable { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Bg)) {
        BrowseScreen(ig, settingsOpen = showSettings, onSettings = { showSettings = true })

        AnimatedVisibility(
            visible = showSettings,
            enter = slideInHorizontally(tween(300)) { it } + fadeIn(tween(200)),
            exit = slideOutHorizontally(tween(250)) { it } + fadeOut(tween(150)),
        ) {
            SettingsScreen(
                cfg = ig.settings,
                saved = ig.state.profiles,
                parseProfiles = ig::parseProfiles,
                onAddProfiles = { ig.addProfiles(it) },
                onBrowser = { showSettings = false; ig.openBrowser() },
                onResetFeed = ig::resetFeed,
                onSignOut = ig::signOut,
                onBack = { showSettings = false },
            )
        }
    }
}
